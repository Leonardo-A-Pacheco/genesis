<h1>WP Cutter-Sanborn</h1>


<p>WP Cutter-Sanborn é um plugin para wordpress que permite colocar um Widget em seu tema para consulta a tabela Cutter.</p>

<img src="https://github.com/bibliotecapucrs/wp_cutter_sanborn/blob/master/screenshot.png">

<hr>

<h1>Objetivos</h1>

<p>O objetivo deste plugin é auxiliar o trabalho dos profissionais de bibliotecas que utilizam Wordpress como plataforma para seus sites.</p>

<h1>Instalação</h1>

<li>Baixe o pacote compactado do plugin</li>
<li>Descompacte dentro de /wordpress/plugins</li>
<li>No painel do Wordpress, vá até plugins e clique em Ativar</li>
<li>Vá no menu Aparência > Widgets e escolha a parte do seu tema em que deverá aparecer o formulário de consulta a tabela Cutter.</li>
<li>Visite sua página e veja o funcionamento</li>
